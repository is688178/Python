311 service request data from [NYC Open Data](https://nycopendata.socrata.com/)

Montréal cycling data from [Données Ouvertes Montréal](http://donnees.ville.montreal.qc.ca/dataset/velos-comptage)
