def todo_mayusculas(texto):
    return texto.upper()
